<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no">

    <title>Site Title</title>

    <link href="assets/img/favicon/apple-touch-icon.png" rel="apple-touch-icon" type="image/png" sizes="180x180">
    <link href="assets/img/favicon/favicon-32x32.png" rel="icon" type="image/png" sizes="32x32">
    <link href="assets/img/favicon/favicon-16x16.png" rel="icon" type="image/png" sizes="16x16">
    <link href="assets/img/favicon/manifest.json" rel="manifest">
    <link href="assets/img/favicon/favicon.ico" rel="shortcut icon">

    <style>
        .site__wrapper {
            opacity: 0;
            -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
            filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
        }
    </style>
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/theme.css">

</head>

<body class="preload">
<div class="top-main-img"></div>
<div class="preload__wrap"></div>

<div class="site__wrapper">

    <header class="header__wrap">
        <div class="main__navbar">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="#">Digimark</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Projects</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Support</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact Us</a>
                    </li>
                    <li class="nav-item mbl-hide">
                        <a class="nav-link primary-btn" href="#" data-toggle="modal" data-target="#quoteModal">Get a Quote</a>
                    </li>
                    </ul>
                </div>
                <a class="nav-link primary-btn quote-btn-mobile" href="#" data-toggle="modal" data-target="#quoteModal">Get a Quote</a>
            </nav>
            </div><!-- /.container -->
        </div><!-- /.main__navbar -->

    </header><!--/.header__wrap-->

