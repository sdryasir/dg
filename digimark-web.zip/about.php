<?php include 'incl/header.php'; ?>

<section class="inner__page__head">
    <figure class="bg_from-child">
        <img src="assets/img/inner-page-bg.jpg" alt="">
    </figure>
    <div class="inner__page__wrapper">
        <div class="container">
            <div class="inner__page__content">
            <h5 class="m-0 text-white"><small>About Us</small></h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                </ol>
            </nav>
            </div>
        </div>
    </div><!-- /.inner__page__title -->
</section><!-- /.inner__page__head -->

<section class="about__page-intro sec-space">
    <div class="container">
        <div class="row d-flex align-items-center">
            <div class="col-md-6">
                <div class="intro_description">
                    <h2>About Digimark</h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Obcaecati id, ullam dicta et numquam molestiae voluptatum voluptate optio vero incidunt at odio deserunt delectus nam eos reprehenderit maxime eaque illum.
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Pariatur eos iure, distinctio id dolore harum magnam quod dignissimos nobis a aliquam asperiores obcaecati. Natus, adipisci commodi perferendis aperiam illo cumque!
                    </p>
                    <ul>
                        <li>Lorem ipsum dolor sit.</li>
                        <li>Lorem ipsum dolor sit amet consectetur.</li>
                        <li>Lorem ipsum dolor sit, amet consectetur adipisicing.</li>
                        <li>Lorem ipsum dolor sit amet.</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6">
                <figure class="bg_from-child">
                    <img src="assets/img/about.svg" alt="">
                </figure>
            </div>
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.introduction -->

<section class="our_team sec-space">
    <div class="container">
        <div class="lead_text-center">
            <h2>Our Amzing Team</h2>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Obcaecati id, ullam dicta et numquam molestiae voluptatum voluptate optio vero incidunt at odio deserunt delectus nam eos reprehenderit maxime eaque illum.
            </p> 
        </div><!-- /.lead_text-center -->          
        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="team__inner text-center">
                    <div class="team_img">
                        <img src="assets/img/male-avatar.jpg" alt="">
                    </div>
                    <h4><small>Mr. Muhammad Aslam</small></h4>
                    <p>Manager Digimark</p>
                    <ul class="team_social-icons">
                        <li><a href=""><span class="icon-facebook"></span></a></li>
                        <li><a href=""><span class="icon-twitter"></span></a></li>
                        <li><a href=""><span class="icon-linkedin2"></span></a></li>
                    </ul>
                </div><!-- /.team__inner -->
            </div><!-- /.col-md-4 -->
            <div class="col-md-4 mb-3">
                <div class="team__inner text-center">
                    <div class="team_img">
                        <img src="assets/img/male-avatar.jpg" alt="">
                    </div>
                    <h4><small>Mr. Muhammad Usman</small></h4>
                    <p>Admin Digimark</p>
                    <ul class="team_social-icons">
                        <li><a href=""><span class="icon-facebook"></span></a></li>
                        <li><a href=""><span class="icon-twitter"></span></a></li>
                        <li><a href=""><span class="icon-linkedin2"></span></a></li>
                    </ul>
                </div><!-- /.team__inner -->
            </div><!-- /.col-md-4 -->
            <div class="col-md-4 mb-3">
                <div class="team__inner text-center">
                    <div class="team_img">
                        <img src="assets/img/male-avatar.jpg" alt="">
                    </div>
                    <h4><small>Mr. Yasir Ali</small></h4>
                    <p>Web Developer Digimark</p>
                    <ul class="team_social-icons">
                        <li><a href=""><span class="icon-facebook"></span></a></li>
                        <li><a href=""><span class="icon-twitter"></span></a></li>
                        <li><a href=""><span class="icon-linkedin2"></span></a></li>
                    </ul>
                </div><!-- /.team__inner -->
            </div><!-- /.col-md-4 -->
        </div><!-- ./row -->
    </div><!-- /.container -->
</section><!-- /.our_team -->



<br><br><br><br><br><br><br><br>
<?php include 'incl/footer.php'; ?>