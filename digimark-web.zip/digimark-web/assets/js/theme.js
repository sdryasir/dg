/**
 * @var $ jQuery
 */

function elFsHeight() {
    let einHeight = $(window).height();
    $('.fs_height').css('min-height', einHeight);
}

/* Window Load ---------------------- */

$(window).on('load', function () {

    setTimeout(function () {
        $('body').toggleClass('preload loaded');
    }, 500);

});


/* Document Ready ---------------------- */

$(document).ready(function () {

    elFsHeight();

    // BG from img src...
    $(".carousel-fs .carousel-inner .carousel-item").each(function () {
        const imgSrc = $(this).find('img').attr('src');
        $(this).css("background-image", "url('" + imgSrc + "')");
    });

    // Inline background image...
    $("[data-bg]").each(function () {
        const image = $(this).attr("data-bg");
        $(this).css({
            backgroundImage: 'url("' + image + '")',
        });
    });

});


/* Window Scroll ---------------------- */

$(window).scroll(function() {

    // Write code here
    var scroll = $(window).scrollTop();
    if (scroll >= 40) {
        $(".main__navbar").addClass("hdr-top-fix");
    } else {
        $(".main__navbar").removeClass("hdr-top-fix");
    }


});


/* Window Resize ---------------------- */

$(window).on('resize', function () {

    elFsHeight();

});