<footer class="footer__wrap sec-space">
    <div class="footer-inner">
        <div class="container">
          <div class="row">
            <div class="col-md-3">
              <h1><small>Digimark</small></h1>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. In ab id soluta laudantium, voluptatem eligendi doloribus ipsum nisi sit architecto veniam fuga officia.</p>
            </div><!-- /.col-md-4 -->
            <div class="col-md-3">
              <h3><small>Important Links</small></h3>
              <ul>
                <li><a href="">Home</a></li>
                <li><a href="">Services</a></li>
                <li><a href="">Projects</a></li>
                <li><a href="">Support</a></li>
                <li><a href="">Blog</a></li>
              </ul>
            </div><!-- /.col-md-4 -->
            <div class="col-md-3">
            <h3><small>Featured Services</small></h3>
            <ul>
                <li><a href="">Digital Marketting</a></li>
                <li><a href="">Search Engine Optimization</a></li>
                <li><a href="">Social Media Promotion</a></li>
                <li><a href="">Support</a></li>
                <li><a href="">Blog</a></li>
              </ul>
            </div><!-- /.col-md-4 -->
            <div class="col-md-3">
            <h3><small>Contact Us</small></h3>
            <ul>
                <li><strong>Address:</strong> Sadaat Arcade, Wallayat Complex, Behria Town Phase VII.</li>
                <li><strong>Email:</strong><a href="mailto:info@digimarks.co.uk"> info@digimarks.co.uk</a></li>
                <li><strong>Contact:</strong><a href="tel:+92 (334) 987 8754"> +92 (334) 987 8754</a></li>
              </ul>
            </div><!-- /.col-md-4 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.footer-inner -->
</footer><!--/.footer__wrap-->

</div><!--/.site__wrapper-->



<!-- Get a quote Modal -->
<div class="modal fade" id="quoteModal" tabindex="-1" role="dialog" aria-labelledby="quoteModal" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="quoteModal">Get a Quote</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="primary-btn">Save changes</button>
      </div>
    </div>
  </div>
</div>

<script src="assets/js/jquery-3.4.1.min.js"></script>
<script src="assets/js/bootstrap.bundle.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/theme.js"></script>
<script>
    $(document).ready(function(){
        $('.clients-carousel').owlCarousel({
            loop:true,
            margin:0,
            nav:true,
            dots:false,
            autoPlay:true,
            autoplayTimeout:1000,
            responsiveClass:true,
            responsive:{
                0:{
                    items:3
                },
                600:{
                    items:3
                },
                1000:{
                    items:5
                }
            }
        })



        $('.client-fedback').owlCarousel({
            loop:true,
            margin:0,
            nav:false,
            dots:true,
            autoPlay:true,
            autoplayTimeout:1000,
            responsiveClass:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                },
                1000:{
                    items:1
                }
            }
        })
    });
</script>
</body>
</html>

