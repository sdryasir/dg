<?php include 'incl/header.php'; ?>

<div class="main__homepage__carousel">
    <div id="homepage__carousel" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <div class="container">
                <div class="carousel-item-inner">
                    <div class="carousel-inner-item">
                        <h1>We are here to solve <br>your<small> business problems</small> </h1>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo, iusto. Omnis id, sunt veritatis numquam libero pariatur consectetur itaque quos illum? Fugiat vitae atque totam repellat. Minus magni inventore ab?
                        </p>
                        <a href="" class="primary-btn">Read More</a>
                    </div><!-- /.carousel-inner-item -->
                    <div class="carousel-inner-item carousel-mbl-hide">
                        <img src="./assets/img/carousel-img.jpg" alt="slider image">
                    </div><!-- /.carousel-inner-item -->
                </div><!-- /.carousel-item-inner -->
            </div><!-- /.container -->
        </div>
    </div>
    <a class="carousel-control-prev" href="#homepage__carousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#homepage__carousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
    </div>
</div><!-- /.main__homepage__carousel -->
<div class="page__wrap">

    
    <div class="client__logo__wrapper sec-space">
        <div class="container">
            <div class="clients-carousel owl-carousel">
                <div class="item">
                    <img src="assets/img/clients/logo1.png" alt="">
                </div>
                <div class="item">
                    <img src="assets/img/clients/logo2.png" alt="">
                </div>
                <div class="item">
                    <img src="assets/img/clients/logo6.png" alt="">
                </div>
                <div class="item">
                    <img src="assets/img/clients/logo4.png" alt="">
                </div>
                <div class="item">
                    <img src="assets/img/clients/logo5.png" alt="">
                </div>
                <div class="item">
                    <img src="assets/img/clients/logo6.png" alt="">
                </div>
            </div>
        </div><!--/.container-->
    </div><!-- /.client__logo__wrapper -->

    <section class="main__page__intro sec-space">
        <div class="container">

        </div><!-- /.container -->
    </section><!-- /.main__page__intro -->
    

</div><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>
