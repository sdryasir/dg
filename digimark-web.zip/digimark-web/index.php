<?php include 'incl/header.php'; ?>
<div class="top-main-img"></div>
<div class="main__homepage__carousel">
    <div id="homepage__carousel" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <div class="container">
                <div class="carousel-item-inner">
                    <div class="carousel-inner-item">
                        <h1>We are here to solve <br>your<small> business problems</small> </h1>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo, iusto. Omnis id, sunt veritatis numquam libero pariatur consectetur itaque quos illum? Fugiat vitae atque totam repellat. Minus magni inventore ab?
                        </p>
                        <a href="" class="primary-btn">Read More</a>
                    </div><!-- /.carousel-inner-item -->
                    <div class="carousel-inner-item carousel-mbl-hide">
                        <img src="./assets/img/carousel-img.jpg" alt="slider image">
                    </div><!-- /.carousel-inner-item -->
                </div><!-- /.carousel-item-inner -->
            </div><!-- /.container -->
        </div>
    </div>
    <a class="carousel-control-prev" href="#homepage__carousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#homepage__carousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
    </div>
</div><!-- /.main__homepage__carousel -->
<div class="page__wrap">

    
    <div class="client__logo__wrapper sec-space">
        <div class="container">
            <div class="clients-carousel owl-carousel">
                <div class="item">
                    <img src="assets/img/clients/logo1.png" alt="">
                </div>
                <div class="item">
                    <img src="assets/img/clients/logo2.png" alt="">
                </div>
                <div class="item">
                    <img src="assets/img/clients/logo6.png" alt="">
                </div>
                <div class="item">
                    <img src="assets/img/clients/logo4.png" alt="">
                </div>
                <div class="item">
                    <img src="assets/img/clients/logo5.png" alt="">
                </div>
                <div class="item">
                    <img src="assets/img/clients/logo6.png" alt="">
                </div>
            </div>
        </div><!--/.container-->
    </div><!-- /.client__logo__wrapper -->

    <section class="main__page__intro sec-space">
        <div class="container">
            <div class="row">
                <div class="col-md-6 d-flx">
                    <div class="intro__inner">
                        <img src="assets/img/digimark_introduction.png" alt="">
                    </div>
                    <!-- /.intro__inner -->
                </div><!-- /.col-md-6 -->
                <div class="col-md-6 d-flx">
                    <div class="intro__inner">
                        <span>About Digimark</span>
                        <h1>Digimarks tells you a lot about <br>your<small> business website</small> </h1>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo, iusto. Omnis id, sunt veritatis numquam libero pariatur consectetur itaque quos illum? Fugiat vitae atque totam repellat. Minus magni inventore ab?
                        </p>
                        <div class="stats-wrapper">
                            <div class="stats-inner">
                                <h1>652+</h1>
                                <span>Happy Clients</span>
                            </div><!-- /.stats-inner -->
                            <div class="stats-inner">
                                <h1>563+</h1>
                                <span>Running Projects</span>
                            </div><!-- /.stats-inner -->
                            <div class="stats-inner">
                                <h1>325+</h1>
                                <span>Completed Projects</span>
                            </div><!-- /.stats-inner -->
                        </div><!-- /.stats-wrapper -->
                    </div><!-- /.intro__inner -->
                </div><!-- /.col-md-6 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.main__page__intro -->
    <section class="services-wrapper sec-space">
        <div class="container">
            <div class="services-inner">
                <div class="service-item-wrapper">
                    <div class="service-inner-item">
                        <span>What we do?</span>
                        <h1>We Provide the Best <br> Services<small> For Clients</small> </h1>
                    </div><!-- /.service-inner-item -->
                    <div class="service-inner-item">
                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Web Design</a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Digital Marketting</a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">UX Design</a>
                            </li>
                        </ul>
                    </div><!-- /.service-inner-item -->
                </div><!-- /.service-item-wrapper -->
            <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="service-box">
                                    <span>icon</span>
                                    <h2>Web Design</h2>  
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius illo optio iste.</p>                                  
                                </div><!-- /.service-box -->
                            </div><!-- /.col-md-4 -->
                            <div class="col-md-4">
                                <div class="service-box">
                                    <span>icon</span>
                                    <h2>Digital Marketting</h2>  
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius illo optio iste.</p>                                  
                                </div><!-- /.service-box -->
                            </div><!-- /.col-md-4 -->
                            <div class="col-md-4">
                                <div class="service-box">
                                    <span>icon</span>
                                    <h2>Web Design</h2>  
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius illo optio iste.</p>                                  
                                </div><!-- /.service-box -->
                            </div><!-- /.col-md-4 -->
                        </div><!-- /.row -->
                    </div>
                    <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum in placeat quas cupiditate veritatis repellat recusandae quis tenetur minus consequatur esse nesciunt reprehenderit.
                    </div>
                    <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consequatur dolore doloribus error!
                    </div>
            </div>    
            </div><!-- /.services-inner -->
        </div><!-- /.container -->
    </section><!-- /.services-wrapper -->

    <section class="choose-us-wrapper sec-space">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="choose-inner">
                        <div class="choose-contents">
                            <span>Choose Us</span>
                            <h1>Everything you need in<br><small> One place</small> </h1>
                            <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo, iusto. Omnis id, sunt veritatis numquam libero pariatur consectetur itaque quos illum? Fugiat vitae atque totam repellat. Minus magni inventore ab?
                            </p>
                            <ul>
                                <li>
                                    <div class="choose-icon">icon</div>
                                    <h3><small>Lorem ipsum dolor sit.</small></h3>
                                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officia consectetur similique quo?</p>
                                </li>
                                <li>
                                    <div class="choose-icon">icon</div>
                                    <h3><small>Lorem ipsum dolor sit.</small></h3>
                                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officia consectetur similique quo?</p>
                                </li>
                            </ul>
                        </div> 
                    </div> <!-- /.choose-inner -->
                </div><!-- /.col-md-6 -->
                <div class="col-md-6">
                    <div class="choose-inner">
                        <img src="assets/img/office-working.svg" alt="">
                    </div><!-- /.choose-inner -->     
                </div><!-- /.col-md-6 -->
            </div><!-- /.row -->  
        </div><!-- /.container -->                          
    </section><!-- /.choose-us-wrapper -->

    <section class="faqs-wrapper sec-space">
            <div class="container">
                    <div class="faq-head">
                        <div class="faq-head-item">
                            <span>Frequently</span>
                            <h1>Frequently Asked<br><small> Questions</small> </h1>
                            <p>
                        </div><!-- /.faq-head-item -->
                        <div class="faq-head-item">
                            <a href="#" class="primary-btn">View All</a>
                        </div><!-- /.faq-head-item -->
                    </div><!-- /.faq-head -->    
            <div class="row">
                <div class="col-md-5">
                    <div class="faq-img">
                        <img class="d-block mx-auto" src="assets/img/faq.svg" alt="faqs">
                    </div><!-- /.faq-img -->
                </div><!-- /.col-md-6 -->
                <div class="col-md-7">
                <div class="accordion" id="accordionExample">
                    <div class="card">
                        <div class="card-header" id="headingOne">
                        <h2 class="mb-0">
                            <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                Do you provide Web design services?
                            </button>
                        </h2>
                        </div>
                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingTwo">
                        <h2 class="mb-0">
                            <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Are you willing to provide Graphic Design Services?
                            </button>
                        </h2>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                        <div class="card-body">
                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                        </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingThree">
                        <h2 class="mb-0">
                            <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            How about illustration work?
                            </button>
                        </h2>
                        </div>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                        <div class="card-body">
                            Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                        </div>
                        </div>
                    </div>
                    </div>
                </div><!-- /.col-md-6 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.faqs-wrapper -->

    <section class="client__feedback__wrapper sec-space">
        <div class="container">
            <div class="client-fedback owl-carousel owl-theme">
                <div class="item">
                    <div class="feedback-inner">
                        <div class="feedback-inner-item">
                            <div class="img-wrapper">
                                <img src="assets/img/client-pic.jpg" alt="">
                            </div><!-- /.img-wrapper -->
                        </div><!-- /.feedback-inner-item -->
                        <div class="feedback-inner-item">
                            <span>Testimonials</span>
                            <h1>Clients <small>Feedback</small></h1>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem dolorem possimus earum quis, dolore esse optio, distinctio nemo odio a sed ipsa quibusdam molestias cumque illo expedita explicabo, obcaecati quod.</p>
                            <h2><small>Mr. Hassan Khan</small></h2>
                            <span>UX/UI Designer</span>
                        </div><!-- /.feedback-inner-item -->
                    </div> <!-- /.feedback-inner -->
                </div><!--/.item-->
                <div class="item">
                    <div class="feedback-inner">
                        <div class="feedback-inner-item">
                            <div class="img-wrapper">
                                <img src="assets/img/client-pic.jpg" alt="">
                            </div><!-- /.img-wrapper -->
                        </div><!-- /.feedback-inner-item -->
                        <div class="feedback-inner-item">
                            <span>Testimonials</span>
                            <h1>Clients <small>Feedback</small></h1>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem dolorem possimus earum quis, dolore esse optio, distinctio nemo odio a sed ipsa quibusdam molestias cumque illo expedita explicabo, obcaecati quod.</p>
                            <h2><small>Mr. Hassan Khan</small></h2>
                            <span>UX/UI Designer</span>
                        </div><!-- /.feedback-inner-item -->
                    </div> <!-- /.feedback-inner -->
                </div><!--/.item-->
                <div class="item">
                    <div class="feedback-inner">
                        <div class="feedback-inner-item">
                            <div class="img-wrapper">
                                <img src="assets/img/client-pic.jpg" alt="">
                            </div><!-- /.img-wrapper -->
                        </div><!-- /.feedback-inner-item -->
                        <div class="feedback-inner-item">
                            <span>Testimonials</span>
                            <h1>Clients <small>Feedback</small></h1>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem dolorem possimus earum quis, dolore esse optio, distinctio nemo odio a sed ipsa quibusdam molestias cumque illo expedita explicabo, obcaecati quod.</p>
                            <h2><small>Mr. Hassan Khan</small></h2>
                            <span>UX/UI Designer</span>
                        </div><!-- /.feedback-inner-item -->
                    </div> <!-- /.feedback-inner -->
                </div><!--/.item-->
            </div><!-- client-fedback -->
        </div><!-- /.container -->
    </section><!-- /.client__feedback__wrapper -->

    <section class="our__team__wrapper sec-space">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-md-6 mb-3">
                    <span>Our Team</span>
                    <h1>Our most Amazing <br>Team <small>Members</small></h1>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis ipsa totam dignissimos perspiciatis commodi explicabo delectus voluptatum facere nemo. Libero.
                    </p>
                    <a class="primary-btn" href="">See More</a>
                </div><!-- /.col-md-6 -->
                <div class="col-md-6">
                    <div class="team-inner">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="team-member-wrapper">
                                    <img class="w-100" src="assets/img/team.png" alt="">
                                    <h3 class="text-center m-0"><small>Mr. Aslam</small></h3>
                                    <p class="text-center mb-1">Manager</p>
                                    <ul class="m-0 p-0">
                                        <li><a href="">fb</a></li>
                                        <li><a href="">tw</a></li>
                                        <li><a href="">lin</a></li>
                                        <li><a href="">ins</a></li>
                                    </ul>
                                </div><!-- /.team-member-wrapper -->
                            </div><!-- /.col-md-6 -->
                            <div class="col-md-6">
                                <div class="team-member-wrapper">
                                    <img class="w-100" src="assets/img/team.png" alt="">
                                    <h3 class="text-center m-0"><small>Mr. Aslam</small></h3>
                                    <p class="text-center mb-1">Manager</p>
                                    <ul class="m-0 p-0">
                                        <li><a href="">fb</a></li>
                                        <li><a href="">tw</a></li>
                                        <li><a href="">lin</a></li>
                                        <li><a href="">ins</a></li>
                                    </ul>
                                </div><!-- /.team-member-wrapper -->
                            </div><!-- /.col-md-6 -->
                            <div class="col-md-6">
                                <div class="team-member-wrapper">
                                    <img class="w-100" src="assets/img/team.png" alt="">
                                    <h3 class="text-center m-0"><small>Mr. Aslam</small></h3>
                                    <p class="text-center mb-1">Manager</p>
                                    <ul class="m-0 p-0">
                                        <li><a href="">fb</a></li>
                                        <li><a href="">tw</a></li>
                                        <li><a href="">lin</a></li>
                                        <li><a href="">ins</a></li>
                                    </ul>
                                </div><!-- /.team-member-wrapper -->
                            </div><!-- /.col-md-6 -->
                            <div class="col-md-6">
                                <div class="team-member-wrapper">
                                    <img class="w-100" src="assets/img/team.png" alt="">
                                    <h3 class="text-center m-0"><small>Mr. Aslam</small></h3>
                                    <p class="text-center mb-1">Manager</p>
                                    <ul class="m-0 p-0">
                                        <li><a href="">fb</a></li>
                                        <li><a href="">tw</a></li>
                                        <li><a href="">lin</a></li>
                                        <li><a href="">ins</a></li>
                                    </ul>
                                </div><!-- /.team-member-wrapper -->
                            </div><!-- /.col-md-6 -->
                        </div><!-- /.row -->
                    </div><!-- /.team-inner -->
                </div><!-- /.col-md-6 -->
            </div><!-- /.row -->  
        </div><!-- /.container -->
    </section><!-- /.our__team__wrapper -->

    <section class="blog__wrapper pb-150">
        <div class="container">
            <div class="blog__inner">
                <div class="blog-head mb-5">
                        <div class="blog-head-item">
                            <span>Our Blog</span>
                            <h1>Our top Latest Updates<br><small> For You</small> </h1>
                            <p>
                        </div><!-- /.blog-head-item -->
                        <div class="blog-head-item">
                            <a href="#" class="primary-btn">View All</a>
                        </div><!-- /.blog-head-item -->
                </div><!-- /.blog-head --> 

                <div class="row">
                    <div class="col-md-4 mb-5">



                        <div class="blog">
                            <div class="blog__item">
                                <img src="assets/img/blog1.svg" alt="">
                            </div><!-- /.blog__item -->
                            <div class="blog-description">
                                    <div class="publish__info">
                                        <div class="publich__item">
                                            <address>Mr. Hassan</address>
                                        </div><!-- /.publich__item -->
                                        <div class="publich__item">
                                            <address>18 Dec 2019</address>
                                        </div><!-- /.publich__item -->
                                    </div><!-- /.publish__info -->
                                    <h3><small>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</small></h3>
                            </div><!-- /.blog-description -->
                        </div><!-- /.blog -->


                        
                    </div><!-- /.col-md-4 -->

                    <div class="col-md-4 mb-5">



                        <div class="blog">
                            <div class="blog__item">
                                <img src="assets/img/blog1.svg" alt="">
                            </div><!-- /.blog__item -->
                            <div class="blog-description">
                                    <div class="publish__info">
                                        <div class="publich__item">
                                            <address>Mr. Hassan</address>
                                        </div><!-- /.publich__item -->
                                        <div class="publich__item">
                                            <address>18 Dec 2019</address>
                                        </div><!-- /.publich__item -->
                                    </div><!-- /.publish__info -->
                                    <h3><small>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</small></h3>
                            </div><!-- /.blog-description -->
                        </div><!-- /.blog -->


                        
                    </div><!-- /.col-md-4 -->

                    <div class="col-md-4">



                        <div class="blog">
                            <div class="blog__item">
                                <img src="assets/img/blog1.svg" alt="">
                            </div><!-- /.blog__item -->
                            <div class="blog-description">
                                    <div class="publish__info">
                                        <div class="publich__item">
                                            <address>Mr. Hassan</address>
                                        </div><!-- /.publich__item -->
                                        <div class="publich__item">
                                            <address>18 Dec 2019</address>
                                        </div><!-- /.publich__item -->
                                    </div><!-- /.publish__info -->
                                    <h3><small>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</small></h3>
                            </div><!-- /.blog-description -->
                        </div><!-- /.blog -->


                        
                    </div><!-- /.col-md-4 -->
                    
                </div><!-- /.row -->
            </div><!-- /.blog__inner -->
        </div><!-- /.container -->
    </section><!-- /.blog__wrapper -->

</div><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>
