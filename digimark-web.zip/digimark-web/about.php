<?php include 'incl/header.php'; ?>

<section class="inner__page__head">
    <img class="w-100" src="assets/img/inner-page-bg.jpg" alt="">
    <div class="inner__page__wrapper">
        <div class="container">
            <div class="inner__page__content">
            <h3 class="m-0"><small>About Us</small></h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                </ol>
            </nav>
            </div>
        </div>
    </div><!-- /.inner__page__title -->
</section><!-- /.inner__page__head -->

<section class="introduction sec-space">
    <div class="container">
        <div class="row d-flex align-items-center">
            <div class="col-md-6">
                <h2>About Digimark</h2>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Obcaecati id, ullam dicta et numquam molestiae voluptatum voluptate optio vero incidunt at odio deserunt delectus nam eos reprehenderit maxime eaque illum.
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Pariatur eos iure, distinctio id dolore harum magnam quod dignissimos nobis a aliquam asperiores obcaecati. Natus, adipisci commodi perferendis aperiam illo cumque!
                </p>
                <ul>
                    <li>Lorem ipsum dolor sit.</li>
                    <li>Lorem ipsum dolor sit amet consectetur.</li>
                    <li>Lorem ipsum dolor sit, amet consectetur adipisicing.</li>
                    <li>Lorem ipsum dolor sit amet.</li>
                </ul>
            </div>
            <div class="col-md-6">
                <img class="w-75 d-block mx-auto" src="assets/img/about.svg" alt="">
            </div>
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.introduction -->



<br><br><br><br><br><br><br><br>
<?php include 'incl/footer.php'; ?>