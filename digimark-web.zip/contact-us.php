<?php include 'incl/header.php'; ?>
<section class="inner__page__head">
    <figure class="bg_from-child">
        <img src="assets/img/inner-page-bg.jpg" alt="">
    </figure>
    <div class="inner__page__wrapper">
        <div class="container">
            <div class="inner__page__content">
            <h5 class="m-0 text-white"><small>Contact Us</small></h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                </ol>
            </nav>
            </div>
        </div>
    </div><!-- /.inner__page__title -->
</section><!-- /.inner__page__head -->

<section class="contact_form-wrapper sec-space">
    <div class="container">
        <div class="row align-items-center">
            
            <div class="col-md-6">
                <div class="contact_form">
                    <form autocomplete="off">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="firstname">First Name</label>
                                <input type="text" class="form-control" placeholder="First name" id="firstname">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="lastname">Last Name</label>
                                <input type="text" class="form-control" placeholder="Last name" id="lastname">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" placeholder="Email" id="email">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="phone">Phone No.</label>
                                <input type="text" class="form-control" placeholder="Phone number" id="phone">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="message">Message</label>
                                <textarea class="form-control" placeholder="Add your message here" name="" id="message"></textarea>
                            </div>
                        </div>
                        <button type="submit" class="primary-btn">Send Message</button>
                    </form>
                </div><!-- /.contact_form -->
            </div><!-- /.col-md-6 -->
            <div class="col-md-6">
                <figure class="bg_from-child">
                    <img src="assets/img/contact-us.svg" alt="">
                </figure>
            </div><!-- /.col-md-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.contact_form-wrapper -->


<section class="map-wrapper">
    <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3325.718402201797!2d73.1098131145401!3d33.534706352273666!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38dfedb50f50247f%3A0x8ec565b432af324b!2sWallayat%20Complex!5e0!3m2!1sen!2s!4v1594724456608!5m2!1sen!2s" width="100%" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0" ></iframe>
    </div>
</section><!-- /.map-wrapper -->
<?php include 'incl/footer.php'; ?>